from collections import Counter
import stemmer 

class Document:
    def __init__(self, id, contents):
        self.doc_id = id
        self.doc_contents = contents


class Mapper:
    def __init__(self, doc_path_list: list):
        self.doc_paths = doc_path_list

    def parseDocument(self) -> list:
        doctype_list = []

        for doc_path in self.doc_paths:
            df = open(doc_path, 'r')
            text_parsing = False
            doc_contents = ''
            doc_id = ''
            for line in df.readlines():
                if line.startswith('<DOCNO>'):
                    doc_id = line.replace('<DOCNO>', '').replace('</DOCNO>', '').replace('\n', '')
                elif line.startswith('<TEXT>'):
                    text_parsing = True
                elif line.startswith('</TEXT>'):
                    text_parsing = False
                    doctype_list.append(Document(doc_id, doc_contents))
                    doc_id, doc_contents = '', ''
                elif text_parsing == True:
                    doc_contents += line

            df.close()
        return doctype_list


def Stem(contents):
    stm = stemmer.Stemmer()
    c = stm.remove_symbol(contents).lower().split('\n')
    for term in c:
        stm.stem(term, 0, len(term)-1)
    return c



if __name__ == '__main__':
    doc_path_list = ['AP88s.txt']
    mapper = Mapper(doc_path_list)
    doc_type_list = mapper.parseDocument()
    
    for doc in doc_type_list:
        doc_id = doc.doc_id
        doc_contents_list = Stem(doc.doc_contents)
        term_list = Counter(doc_contents_list)
        print(term_list)
        break
        
        
        


