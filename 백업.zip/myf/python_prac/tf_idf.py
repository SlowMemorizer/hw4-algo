import math
import stemmer


class TF_IDF:
    def __init__(self, post_list_path):
        self.param = {"idf_N": 0, "icf_N": 0}
        self.porter = stemmer.Stemmer()
        self.posting_list, self.param['icf_N'], self.param['idf_N'] = self.__file_to_dic(post_list_path)


    def __file_to_dic(self, file_path):
        temp_post_list = {}
        col_N = 0
        doc_N = 0
        with open(file_path) as f:
            for line in f:
                w2d = line.replace('\n', '').strip().split(":")
                term, docs = w2d[0].strip().split(), w2d[1].strip().split()
                col_freq = int(term[1].replace('[', '').replace(']', ''))
                col_N += col_freq
                temp_post_list[term[0]] = {'col_freq': col_freq, 'docs': {}}
                for doc in docs:
                    fnp = doc.split('#')
                    f_path, term_freq = fnp[0], int(fnp[1])
                    temp_post_list[term[0]]['docs'][f_path] = term_freq
                doc_freq = len(temp_post_list[term[0]]['docs'].items())
                temp_post_list[term[0]]['doc_freq'] = doc_freq
                doc_N += doc_freq

        return temp_post_list, col_N, doc_N


    def word_tf(self, term, doc_name):
        return 1 + math.log(self.posting_list[term]['docs'][doc_name] *1.0)

    def word_idf(self, term):
        return math.log(float(self.param['idf_N']) / self.posting_list[term]['doc_freq'])

    def calc_sent_ifidf(self, sentence):
        query = sentence.strip().split()
        score_lst = {}
        for term in query:
            if term in self.posting_list:
                for doc in self.posting_list[term]['docs']:
                    if doc in score_lst:
                        score_lst[doc] += self.word_tf(term, doc) * self.word_idf(term)
                    else:
                        score_lst[doc] = self.word_tf(term, doc) * self.word_idf(term)
        return score_lst

    def print_sorted_tfidf(self, sent):
        # query를 term의 리스트로 정제
        terms = self.porter.remove_symbol(sent.lower().strip().replace('\n', '')).split()
        # 각 term을 stem
        for i in range(0, len(terms)): 
            terms[i] = self.porter.stem(terms[i], 0, len(terms[i])-1)    
        # stemming된 term을 하나의 문장으로 변환
        sentence = ' '.join(x for x in terms)

        sc_lst = self.calc_sent_ifidf(sentence)
        sc_lst = sorted(sc_lst.items(), key=(lambda x:x[1]), reverse=True)
        print('stemmed input query: %s' % sentence)
        print(' [doc_no | tf_idf]')
        for doc, score in sc_lst[:5]:
            print(' [%s | %f]' %(doc, score))
        print('='*50)

if __name__ == '__main__':
    score = TF_IDF('./awked_AP88s.txt')
    print('=' * 50)
    while True:
        query = input("input query: ")
        score.print_sorted_tfidf(query)