from collections import Counter, defaultdict
from typing import List
import sys 
import json
import stemmer


class Document:
    def __init__(self, doc_id: str, doc_contents: str):
        self.id = doc_id
        self.contents = doc_contents



class DocumentParser:
    def __init__(self, doc_paths: List[str]):
        self.doc_paths = doc_paths
        
    def parseDocument(self):
        doc_type_list = []
        total_doc = []
        for doc_path in self.doc_paths:
            df = open(doc_path, 'r')
            doc_id = ''
            doc_contents = ''
            lines = df.readlines()
            text_activated = False
            for line in lines:
                if line.startswith('<DOCNO>'):
                    doc_id = line.replace('<DOCNO>', '').replace('</DOCNO>', '').replace('\n', '').strip()
                elif line.startswith('<TEXT>'):
                    text_activated = True
                elif line.startswith('</TEXT>'):
                    text_activated = False
                    total_doc.append(doc_id)
                    doc_type_list.append(Document(doc_id, doc_contents))
                    doc_id, doc_contents = '', ''
                elif text_activated:
                    doc_contents += line 
            df.close()    
        total_doc_num = len(Counter(total_doc).keys())
        return doc_type_list, total_doc_num



class Indexer:
    def __init__(self, doc_list: List[Document], total_doc_num):
        self.doc_list = doc_list
        self.total_doc_num = total_doc_num
        self.total_term_freq = 0


    def preprocess(self, doc_contents: str):
        stm = stemmer.Stemmer()
        term_list = stm.remove_symbol(doc_contents).replace('\n', '').lower().strip().split()
        for i in range(0, len(term_list)):
            term_list[i] = stm.stem(term_list[i])
        return term_list


    def indexSingle(self, doc: Document):
        doc_id = doc.id
        single_inverted = Counter(self.preprocess(doc.contents))
        for term in single_inverted:
            single_inverted[term] = {
                'docs': Counter({doc_id: single_inverted[term]})
            }
        return single_inverted


    def indexAll(self):
        single_inverted_list = []
        for doc in self.doc_list:
            single_inverted = self.indexSingle(doc)
            single_inverted_list.append(single_inverted)

        base = single_inverted_list[0]
        for single_inv in single_inverted_list[1:]: 
            for term in single_inv:
                if term in base:
                    base[term]['docs'] += single_inv[term]['docs']
                else:
                    base[term] = single_inv[term]

        for term in base:
            base[term]['doc_freq'] = len(base[term]['docs'].keys())        
            base[term]['col_freq'] = sum(base[term]['docs'].values())        
            self.total_term_freq += base[term]['col_freq']
        
        base['total_doc_num'] = self.total_doc_num
        base['total_term_freq'] = self.total_term_freq
        return base



if __name__ == '__main__':
    doc_path_list = sys.argv[1:]
    docs, total_doc_num = DocumentParser(doc_path_list).parseDocument()
    inverted_index = Indexer(docs, total_doc_num).indexAll()
    inv_idx = json.dumps(inverted_index, indent=4)
    print(inv_idx)
    
        
        