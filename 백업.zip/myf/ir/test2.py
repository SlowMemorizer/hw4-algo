from collections import Counter

dic = {'term1': {'docs': Counter({'a': 1, 'b': 2})}}
dic2 = {'term': {'docs': Counter({'a': 1, 'b': 2})}}


dic['term'] = dic2['term']

print(dic)