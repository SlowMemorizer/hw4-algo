use std::io::prelude::*;
use std::fs::File;

fn main() -> std::io::Result<()> {
    let mut file = File::create("foo.txt")?;
    let () = file;
    Ok(())
}
