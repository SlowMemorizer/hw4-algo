# -*- coding:utf-8 -*-
import sys  # sys.maxsize 


def findMinCountToMultiply(d, n):
    m = [ [0 for x in range(n)] for y in range(n) ] 
    min_path = [ [0 for x in range(n)] for y in range(n) ] 

    for chain in range(1, n):
        for begin in range(1, n-chain):
            end = begin + chain   # begin ~~~ end 
            m[begin][end] = sys.maxsize
            for k in range(begin, end):   # k = 구분자  
                current_cost = m[begin][end]
                new_cost = m[begin][k] + m[k+1][end] + d[begin-1]*d[k]*d[end]
                if new_cost < current_cost:  
                    m[begin][end] = new_cost
                    min_path[begin][end] = k
    return m, min_path


def findMinOrder(min_path, b, e):
    if e - b == 1:
        print('[{},{}]'.format(b, e), end='')
        return
    elif e - b == 0:
        print('{}'.format(b), end='')
        return
    
    k = min_path[b][e]
    print('( ', end='')
    findMinOrder(min_path, b, k)
    print(' )*( ', end='')
    findMinOrder(min_path, k+1, e)
    print(' )', end='')
    

if __name__ == '__main__':    
    dimensions = [1, 2, 3, 4, 5]
    size = len(dimensions)
    lst, min_path = findMinCountToMultiply(dimensions, size)
    findMinOrder(min_path, 1, len(dimensions)-1)
    print('\ncount = {}'.format(lst[1][size-1]))